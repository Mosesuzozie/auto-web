package vip.autotrap.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public final class AutomationController {
    private int webTimer;
    private int plateTimer;
    private int obbyTimer;

    private PlayerEntity target;
    private List<PlanStep> plan = List.of();
    private int planIndex;
    private int preparedSlot = -1;
    private int selectionWait;
    private int actionWait;
    private int originalSlot = -1;

    public void tick(MinecraftClient client) {
        if (!AutoTrapConfig.enabled) {
            clearPlan(client);
            return;
        }

        if (selectionWait > 0) {
            selectionWait--;
            return;
        }
        if (actionWait > 0) {
            actionWait--;
            return;
        }

        if (!plan.isEmpty()) {
            runPlan(client);
            return;
        }

        webTimer++;
        plateTimer++;
        obbyTimer++;

        if (AutoTrapConfig.autoObbyEnabled && obbyTimer >= ticks(AutoTrapConfig.autoObbyIntervalSeconds)) {
            target = AutoTrapClient.findVisibleTarget(client);
            if (target != null && startObby(client, target)) {
                obbyTimer = 0;
                return;
            }
            obbyTimer = 0;
        }

        if (AutoTrapConfig.normalWebEnabled && webTimer >= ticks(AutoTrapConfig.normalWebIntervalSeconds)) {
            target = AutoTrapClient.findVisibleTarget(client);
            if (target != null && startNormalWeb(target)) {
                webTimer = 0;
                return;
            }
            webTimer = 0;
        }

        if (AutoTrapConfig.pressurePlateWebEnabled && plateTimer >= ticks(AutoTrapConfig.pressurePlateWebIntervalSeconds)) {
            target = AutoTrapClient.findVisibleTarget(client);
            if (target != null && startPressurePlateWeb(client, target)) {
                plateTimer = 0;
                return;
            }
            plateTimer = 0;
        }
    }

    private void runPlan(MinecraftClient client) {
        if (target == null || target.isRemoved() || target.isDead()) {
            clearPlan(client);
            return;
        }
        if (AutoTrapConfig.onlyVisibleTargets && client.player != null && !client.player.canSee(target)) {
            clearPlan(client);
            return;
        }

        if (planIndex >= plan.size()) {
            restoreSlot(client);
            clearPlan(client);
            return;
        }

        PlanStep step = plan.get(planIndex);
        BlockHitResult hit = PlacementUtil.findPlacementHit(client, step.pos());
        if (hit == null) {
            // The target/terrain can change between ticks. Re-check until the spot is valid.
            return;
        }

        float[] wanted = PlacementUtil.rotationsTo(client.player.getEyePos(), hit.getPos());
        smoothLook(client.player, wanted[0], wanted[1]);

        float yawDelta = Math.abs(wrapDegrees(wanted[0] - client.player.getYaw()));
        float pitchDelta = Math.abs(wanted[1] - client.player.getPitch());
        if (yawDelta > AutoTrapConfig.rotationTolerance || pitchDelta > AutoTrapConfig.rotationTolerance) return;

        if (preparedSlot == -1) {
            if (planIndex == 0 && selectionWait == 0 && actionWait == 0 && originalSlot < 0) {
                originalSlot = client.player.getInventory().getSelectedSlot();
            }
            int slot = PlacementUtil.findHotbarSlot(client.player, step.item());
            if (slot == -1) {
                planIndex++;
                return;
            }
            client.player.getInventory().setSelectedSlot(slot);
            preparedSlot = slot;
            selectionWait = 1;
            return;
        }

        PlacementUtil.place(client, hit);
        preparedSlot = -1;
        planIndex++;
        actionWait = step.delayAfterTicks();
    }

    private boolean startNormalWeb(PlayerEntity target) {
        List<PlanStep> steps = new ArrayList<>();
        BlockPos feet = target.getBlockPos();
        if (AutoTrapConfig.normalWebFeet) steps.add(new PlanStep(feet, Items.COBWEB, 1));
        if (AutoTrapConfig.normalWebHead) steps.add(new PlanStep(feet.up(), Items.COBWEB, 1));
        return beginPlan(steps);
    }

    private boolean startPressurePlateWeb(MinecraftClient client, PlayerEntity target) {
        List<PlanStep> steps = new ArrayList<>();
        BlockPos feet = target.getBlockPos();
        // Plate goes on the block the target is standing on, then the web goes at head level.
        if (clientHasPlateSupport(client, feet)) {
            steps.add(new PlanStep(feet, Items.STONE_PRESSURE_PLATE, 1));
            if (AutoTrapConfig.pressurePlateWebHead) steps.add(new PlanStep(feet.up(), Items.COBWEB, 1));
        }
        return beginPlan(steps);
    }

    private boolean startObby(MinecraftClient client, PlayerEntity target) {
        BlockPos feet = target.getBlockPos();
        Direction wall = findWallDirection(client, feet);
        if (wall == null) return false;

        Direction front = wall.getOpposite();
        List<PlanStep> steps = new ArrayList<>();
        for (int i = 0; i < AutoTrapConfig.autoObbyBlockCount; i++) {
            steps.add(new PlanStep(feet.offset(front).up(i), Items.OBSIDIAN, 1));
        }

        if (AutoTrapConfig.autoObbyLava) {
            steps.add(new PlanStep(feet, Items.LAVA_BUCKET, AutoTrapConfig.autoObbyWaterDelayTicks));
        }
        if (AutoTrapConfig.autoObbyWater) {
            steps.add(new PlanStep(feet, Items.WATER_BUCKET, 1));
        }
        return beginPlan(steps);
    }

    private Direction findWallDirection(MinecraftClient client, BlockPos feet) {
        for (Direction direction : new Direction[]{Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST}) {
            BlockPos beside = feet.offset(direction);
            var state = client.world.getBlockState(beside);
            if (!state.isAir() && !state.isReplaceable()) return direction;
        }
        return null;
    }

    private boolean clientHasPlateSupport(MinecraftClient client, BlockPos feet) {
        // A pressure plate must have a solid-ish supporting block below it.
        if (client.world == null) return false;
        var below = client.world.getBlockState(feet.down());
        return !below.isAir() && !below.isReplaceable();
    }

    private boolean beginPlan(List<PlanStep> steps) {
        if (steps.isEmpty()) return false;
        this.plan = List.copyOf(steps);
        this.planIndex = 0;
        this.preparedSlot = -1;
        this.selectionWait = 0;
        this.actionWait = 0;
        this.originalSlot = -1;
        return true;
    }

    private void restoreSlot(MinecraftClient client) {
        if (client.player != null) {
            client.player.getInventory().setSelectedSlot(originalSlot);
        }
    }

    private void clearPlan(MinecraftClient client) {
        if (!plan.isEmpty()) restoreSlot(client);
        plan = List.of();
        planIndex = 0;
        originalSlot = -1;
        preparedSlot = -1;
        selectionWait = 0;
        actionWait = 0;
        target = null;
    }

    private static int ticks(int seconds) {
        return Math.max(1, seconds * 20);
    }

    private static void smoothLook(ClientPlayerEntity player, float targetYaw, float targetPitch) {
        float yawDelta = wrapDegrees(targetYaw - player.getYaw());
        float pitchDelta = targetPitch - player.getPitch();
        float maxStep = Math.max(1.0f, AutoTrapConfig.rotationSpeed);
        player.setYaw(player.getYaw() + clamp(yawDelta, -maxStep, maxStep));
        player.setPitch(player.getPitch() + clamp(pitchDelta, -maxStep, maxStep));
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static float wrapDegrees(float value) {
        value %= 360.0f;
        if (value >= 180.0f) value -= 360.0f;
        if (value < -180.0f) value += 360.0f;
        return value;
    }

    private record PlanStep(BlockPos pos, Item item, int delayAfterTicks) {}
}
