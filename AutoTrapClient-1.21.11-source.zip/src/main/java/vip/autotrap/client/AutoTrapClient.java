package vip.autotrap.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;

public final class AutoTrapClient implements ClientModInitializer {
    public static final String MOD_ID = "autotrapclient";
    public static AutomationController CONTROLLER;

    @Override
    public void onInitializeClient() {
        AutoTrapConfig.load();
        CONTROLLER = new AutomationController();
        ClientTickEvents.END_CLIENT_TICK.register(AutoTrapClient::tick);
    }

    private static void tick(MinecraftClient client) {
        if (client.player == null || client.world == null || client.interactionManager == null) return;
        CONTROLLER.tick(client);
    }

    public static PlayerEntity findVisibleTarget(MinecraftClient client) {
        if (client.player == null || client.world == null) return null;

        PlayerEntity self = client.player;
        double range = AutoTrapConfig.targetRange;
        Box search = self.getBoundingBox().expand(range);
        PlayerEntity best = null;
        double bestDistance = Double.MAX_VALUE;

        for (PlayerEntity candidate : client.world.getEntitiesByClass(
                PlayerEntity.class,
                search,
                p -> p != self && !p.isDead() && !p.isSpectator()
        )) {
            if (AutoTrapConfig.onlyVisibleTargets && !self.canSee(candidate)) continue;
            double distance = self.squaredDistanceTo(candidate);
            if (distance < bestDistance) {
                best = candidate;
                bestDistance = distance;
            }
        }
        return best;
    }
}
