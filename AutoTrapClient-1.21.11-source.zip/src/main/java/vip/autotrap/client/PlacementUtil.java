package vip.autotrap.client;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.hit.BlockHitResult;

public final class PlacementUtil {
    private PlacementUtil() {}

    public static int findHotbarSlot(ClientPlayerEntity player, Item item) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (!stack.isEmpty() && stack.isOf(item)) return i;
        }
        return -1;
    }

    public static BlockHitResult findPlacementHit(MinecraftClient client, BlockPos targetPos) {
        if (client.player == null || client.world == null) return null;
        BlockState target = client.world.getBlockState(targetPos);
        if (!target.isReplaceable()) return null;

        for (Direction face : Direction.values()) {
            BlockPos support = targetPos.offset(face.getOpposite());
            BlockState supportState = client.world.getBlockState(support);
            if (supportState.isAir() || supportState.isReplaceable()) continue;
            if (client.player.getEyePos().squaredDistanceTo(support.toCenterPos()) > 25.0) continue;

            Vec3d hitPos = support.toCenterPos().add(
                    face.getOffsetX() * 0.49,
                    face.getOffsetY() * 0.49,
                    face.getOffsetZ() * 0.49
            );
            return new BlockHitResult(hitPos, face, support, false);
        }
        return null;
    }

    public static boolean place(MinecraftClient client, BlockHitResult hit) {
        if (client.player == null || client.interactionManager == null) return false;
        client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND, hit);
        client.player.swingHand(Hand.MAIN_HAND);
        return true;
    }

    public static float[] rotationsTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double dz = to.z - from.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) (-Math.toDegrees(Math.atan2(dy, horizontal)));
        return new float[]{yaw, pitch};
    }
}
