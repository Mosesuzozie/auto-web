package vip.autotrap.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CyclingButtonWidget;
import net.minecraft.text.Text;

import java.util.function.Consumer;
import java.util.function.IntConsumer;

public final class AutoTrapConfigScreen extends Screen {
    private enum Tab { GENERAL, WEB, OBBY }

    private final Screen parent;
    private Tab tab = Tab.GENERAL;

    public AutoTrapConfigScreen(Screen parent) {
        super(Text.literal("AutoTrap Client Settings"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        rebuild();
    }

    private void rebuild() {
        clearChildren();
        int center = width / 2;

        addDrawableChild(ButtonWidget.builder(Text.literal("General"), b -> switchTab(Tab.GENERAL))
                .dimensions(center - 180, 35, 110, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Web"), b -> switchTab(Tab.WEB))
                .dimensions(center - 55, 35, 110, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Obby"), b -> switchTab(Tab.OBBY))
                .dimensions(center + 70, 35, 110, 20).build());

        switch (tab) {
            case GENERAL -> general(center);
            case WEB -> web(center);
            case OBBY -> obby(center);
        }

        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(center - 75, height - 35, 150, 20).build());
    }

    private void general(int center) {
        addToggle(center, 75, "Master enabled", () -> AutoTrapConfig.enabled, v -> AutoTrapConfig.enabled = v);
        addToggle(center, 105, "Only target visible players", () -> AutoTrapConfig.onlyVisibleTargets, v -> AutoTrapConfig.onlyVisibleTargets = v);
        addInt(center, 135, "Target range", AutoTrapConfig.targetRange, new int[]{4, 6, 8, 10, 12, 16, 20, 24, 32}, v -> AutoTrapConfig.targetRange = v, " blocks");
        addInt(center, 165, "Smooth rotation speed", AutoTrapConfig.rotationSpeed, new int[]{2, 4, 6, 8, 10, 12, 16, 20, 24}, v -> AutoTrapConfig.rotationSpeed = v, " deg/tick");
        addInt(center, 195, "Rotation tolerance", AutoTrapConfig.rotationTolerance, new int[]{1, 2, 3, 4, 5, 6}, v -> AutoTrapConfig.rotationTolerance = v, "°");
    }

    private void web(int center) {
        addToggle(center, 75, "Normal web", () -> AutoTrapConfig.normalWebEnabled, v -> AutoTrapConfig.normalWebEnabled = v);
        addInt(center, 105, "Normal web interval", AutoTrapConfig.normalWebIntervalSeconds, range(1, 15), v -> AutoTrapConfig.normalWebIntervalSeconds = v, " s");
        addToggle(center, 135, "Normal web feet", () -> AutoTrapConfig.normalWebFeet, v -> AutoTrapConfig.normalWebFeet = v);
        addToggle(center, 165, "Normal web head", () -> AutoTrapConfig.normalWebHead, v -> AutoTrapConfig.normalWebHead = v);

        addToggle(center, 210, "Pressure-plate web", () -> AutoTrapConfig.pressurePlateWebEnabled, v -> AutoTrapConfig.pressurePlateWebEnabled = v);
        addInt(center, 240, "Plate web interval", AutoTrapConfig.pressurePlateWebIntervalSeconds, range(1, 15), v -> AutoTrapConfig.pressurePlateWebIntervalSeconds = v, " s");
        addToggle(center, 270, "Plate web head", () -> AutoTrapConfig.pressurePlateWebHead, v -> AutoTrapConfig.pressurePlateWebHead = v);
    }

    private void obby(int center) {
        addToggle(center, 75, "Auto obby", () -> AutoTrapConfig.autoObbyEnabled, v -> AutoTrapConfig.autoObbyEnabled = v);
        addInt(center, 105, "Auto obby interval", AutoTrapConfig.autoObbyIntervalSeconds, new int[]{5, 10, 15, 20, 25, 30, 40, 60}, v -> AutoTrapConfig.autoObbyIntervalSeconds = v, " s");
        addInt(center, 135, "Obsidian blocks", AutoTrapConfig.autoObbyBlockCount, new int[]{1, 2, 3, 4}, v -> AutoTrapConfig.autoObbyBlockCount = v, " blocks");
        addToggle(center, 165, "Place lava", () -> AutoTrapConfig.autoObbyLava, v -> AutoTrapConfig.autoObbyLava = v);
        addToggle(center, 195, "Place water", () -> AutoTrapConfig.autoObbyWater, v -> AutoTrapConfig.autoObbyWater = v);
        addInt(center, 225, "Water delay", AutoTrapConfig.autoObbyWaterDelayTicks, new int[]{1, 2, 3, 4, 5, 6, 8, 10, 15, 20}, v -> AutoTrapConfig.autoObbyWaterDelayTicks = v, " ticks");
    }

    private void addToggle(int center, int y, String label, java.util.function.BooleanSupplier getter, Consumer<Boolean> setter) {
        CyclingButtonWidget<Boolean> b = CyclingButtonWidget.onOffBuilder(getter.getAsBoolean())
                .build(center - 160, y, 320, 20, Text.literal(label), (button, value) -> {
                    setter.accept(value);
                    AutoTrapConfig.save();
                });
        addDrawableChild(b);
    }

    private void addInt(int center, int y, String label, int current, int[] values, IntConsumer setter, String suffix) {
        CyclingButtonWidget.Builder<Integer> builder = CyclingButtonWidget.builder(
                value -> Text.literal(value + suffix),
                () -> current
        ).values(values);
        addDrawableChild(builder.build(center - 160, y, 320, 20, Text.literal(label), (button, value) -> {
            setter.accept(value);
            AutoTrapConfig.save();
        }));
    }


    private void switchTab(Tab next) {
        AutoTrapConfig.save();
        tab = next;
        rebuild();
    }

    private int[] range(int min, int max) {
        int[] result = new int[max - min + 1];
        for (int i = 0; i < result.length; i++) result[i] = min + i;
        return result;
    }

    @Override
    public void close() {
        AutoTrapConfig.save();
        client.setScreen(parent);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 12, 0xFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }
}
