package vip.autotrap.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

public final class AutoTrapConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("autotrap-client.json");

    public static boolean enabled = true;
    public static boolean onlyVisibleTargets = true;
    public static int targetRange = 12;
    public static int rotationSpeed = 10;
    public static int rotationTolerance = 2;

    public static boolean normalWebEnabled = true;
    public static int normalWebIntervalSeconds = 5;
    public static boolean normalWebFeet = true;
    public static boolean normalWebHead = true;

    public static boolean pressurePlateWebEnabled = true;
    public static int pressurePlateWebIntervalSeconds = 5;
    public static boolean pressurePlateWebHead = true;

    public static boolean autoObbyEnabled = true;
    public static int autoObbyIntervalSeconds = 20;
    public static int autoObbyBlockCount = 2;
    public static boolean autoObbyLava = true;
    public static boolean autoObbyWater = true;
    public static int autoObbyWaterDelayTicks = 4;

    private AutoTrapConfig() {}

    public static void load() {
        if (!Files.exists(FILE)) {
            save();
            return;
        }

        try (Reader reader = Files.newBufferedReader(FILE)) {
            JsonObject o = JsonParser.parseReader(reader).getAsJsonObject();
            enabled = bool(o, "enabled", enabled);
            onlyVisibleTargets = bool(o, "onlyVisibleTargets", onlyVisibleTargets);
            targetRange = integer(o, "targetRange", targetRange, 2, 32);
            rotationSpeed = integer(o, "rotationSpeed", rotationSpeed, 1, 30);
            rotationTolerance = integer(o, "rotationTolerance", rotationTolerance, 1, 8);

            normalWebEnabled = bool(o, "normalWebEnabled", normalWebEnabled);
            normalWebIntervalSeconds = integer(o, "normalWebIntervalSeconds", normalWebIntervalSeconds, 1, 30);
            normalWebFeet = bool(o, "normalWebFeet", normalWebFeet);
            normalWebHead = bool(o, "normalWebHead", normalWebHead);

            pressurePlateWebEnabled = bool(o, "pressurePlateWebEnabled", pressurePlateWebEnabled);
            pressurePlateWebIntervalSeconds = integer(o, "pressurePlateWebIntervalSeconds", pressurePlateWebIntervalSeconds, 1, 30);
            pressurePlateWebHead = bool(o, "pressurePlateWebHead", pressurePlateWebHead);

            autoObbyEnabled = bool(o, "autoObbyEnabled", autoObbyEnabled);
            autoObbyIntervalSeconds = integer(o, "autoObbyIntervalSeconds", autoObbyIntervalSeconds, 5, 60);
            autoObbyBlockCount = integer(o, "autoObbyBlockCount", autoObbyBlockCount, 1, 4);
            autoObbyLava = bool(o, "autoObbyLava", autoObbyLava);
            autoObbyWater = bool(o, "autoObbyWater", autoObbyWater);
            autoObbyWaterDelayTicks = integer(o, "autoObbyWaterDelayTicks", autoObbyWaterDelayTicks, 1, 20);
        } catch (Exception ignored) {
            save();
        }
    }

    public static void save() {
        try {
            Files.createDirectories(FILE.getParent());
            JsonObject o = new JsonObject();
            o.addProperty("enabled", enabled);
            o.addProperty("onlyVisibleTargets", onlyVisibleTargets);
            o.addProperty("targetRange", targetRange);
            o.addProperty("rotationSpeed", rotationSpeed);
            o.addProperty("rotationTolerance", rotationTolerance);

            o.addProperty("normalWebEnabled", normalWebEnabled);
            o.addProperty("normalWebIntervalSeconds", normalWebIntervalSeconds);
            o.addProperty("normalWebFeet", normalWebFeet);
            o.addProperty("normalWebHead", normalWebHead);

            o.addProperty("pressurePlateWebEnabled", pressurePlateWebEnabled);
            o.addProperty("pressurePlateWebIntervalSeconds", pressurePlateWebIntervalSeconds);
            o.addProperty("pressurePlateWebHead", pressurePlateWebHead);

            o.addProperty("autoObbyEnabled", autoObbyEnabled);
            o.addProperty("autoObbyIntervalSeconds", autoObbyIntervalSeconds);
            o.addProperty("autoObbyBlockCount", autoObbyBlockCount);
            o.addProperty("autoObbyLava", autoObbyLava);
            o.addProperty("autoObbyWater", autoObbyWater);
            o.addProperty("autoObbyWaterDelayTicks", autoObbyWaterDelayTicks);

            try (Writer writer = Files.newBufferedWriter(FILE)) {
                GSON.toJson(o, writer);
            }
        } catch (Exception ignored) {
        }
    }

    private static boolean bool(JsonObject o, String key, boolean fallback) {
        return o.has(key) && o.get(key).isJsonPrimitive() ? o.get(key).getAsBoolean() : fallback;
    }

    private static int integer(JsonObject o, String key, int fallback, int min, int max) {
        if (!o.has(key) || !o.get(key).isJsonPrimitive()) return fallback;
        return Math.max(min, Math.min(max, o.get(key).getAsInt()));
    }
}
